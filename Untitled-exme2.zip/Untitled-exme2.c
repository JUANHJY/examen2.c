#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Definiciones de Estados */
typedef enum {
    MODE_RUN = 0,
    MODE_PAUSE = 1
} SystemMode_t;

/* Variables Globales del Sistema */
volatile uint32_t ms_ticks = 0;
uint32_t t_counter_ms = 0;

// Parámetros de proceso
uint16_t adc_raw = 0;
uint8_t pct = 0;
uint8_t thr = 70;
SystemMode_t current_mode = MODE_RUN;
uint8_t alarm_state = 0;
uint8_t valid_sample_received = 0;

// UART Buffer de Recepción
#define UART_RX_BUF_SIZE 64
char rx_buffer[UART_RX_BUF_SIZE];
uint8_t rx_index = 0;
uint8_t rx_data;
volatile uint8_t line_ready = 0;

// Prototipos de funciones
void SystemClock_Config(void);
void Peripherals_Init(void);
void Process_Command(char* cmd);
void Send_Telemetry(void);
void Send_Status(void);
uint8_t Calculate_Percentage(uint16_t raw);

int main(void) {
    HAL_Init();
    SystemClock_Config();
    Peripherals_Init();

    // Habilitar recepción UART por interrupción (1 byte a la vez)
    HAL_UART_Receive_IT(&huart2, &rx_data, 1);

    while (1) {
        // 1. Procesamiento de Comandos UART (fuera de la ISR)
        if (line_ready) {
            Process_Command(rx_buffer);
            rx_index = 0;
            line_ready = 0;
        }

        // 2. Tareas programadas por marcas de tiempo lógicas (actualizadas en el Timer Tick de 10 ms)
        static uint32_t last_adc_tick = 0;
        static uint32_t last_led_tick = 0;
        static uint32_t last_telemetry_tick = 0;
        uint32_t current_ticks = ms_ticks;

        // Cada 100 ms: Adquisición ADC y Lógica de Alarma con Histéresis
        if (current_ticks - last_adc_tick >= 100) {
            last_adc_tick = current_ticks;
            
            HAL_ADC_Start(&hadc1);
            if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
                adc_raw = HAL_ADC_GetValue(&hadc1);
                pct = Calculate_Percentage(adc_raw);
                valid_sample_received = 1;
            }
            HAL_ADC_Stop(&hadc1);

            // Control de Alarma (Requisito Funcional #5)
            if (current_mode == MODE_RUN && valid_sample_received) {
                if (alarm_state == 0) {
                    if (pct >= thr) alarm_state = 1;
                } else {
                    if (pct < (thr - 5)) alarm_state = 0;
                }
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, alarm_state ? GPIO_PIN_SET : GPIO_PIN_RESET);
            } else {
                alarm_state = 0;
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
            }
        }

        // Cada 500 ms: Toggle LED de actividad
        if (current_ticks - last_led_tick >= 500) {
            last_led_tick = current_ticks;
            HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
        }

        // Cada 1000 ms: Telemetría UART
        if (current_ticks - last_telemetry_tick >= 1000) {
            last_telemetry_tick = current_ticks;
            t_counter_ms = current_ticks;
            Send_Telemetry();
        }
    }
}

/* Interrupción del TIMER de Hardware (TIM2 cada 10 ms) y antirrebotes de botón */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM2) {
        ms_ticks += 10;

        // Máquina de estados para Botón con antirrebotes (requiere 30 ms estables)
        static GPIO_PinState last_steady_state = GPIO_PIN_SET; // Pull-up: inactivo HIGH
        static GPIO_PinState current_sample = GPIO_PIN_SET;
        static uint8_t stable_count = 0;

        GPIO_PinState pin_val = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13); // Pulsador activo LOW

        if (pin_val == current_sample) {
            if (stable_count < 3) stable_count++;
        } else {
            current_sample = pin_val;
            stable_count = 1;
        }

        if (stable_count >= 3 && current_sample != last_steady_state) {
            last_steady_state = current_sample;
            // Flanco de bajada detectado (presión válida en lógica inversa)
            if (current_sample == GPIO_PIN_RESET) {
                if (current_mode == MODE_RUN) {
                    current_mode = MODE_PAUSE;
                    alarm_state = 0;
                } else {
                    current_mode = MODE_RUN;
                    if (valid_sample_received) {
                        alarm_state = (pct >= thr) ? 1 : 0;
                    }
                }
            }
        }
    }
}

/* Interrupción de recepción UART por carácter */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        if (!line_ready) {
            if (rx_data == '\n' || rx_data == '\r') {
                if (rx_index > 0) {
                    rx_buffer[rx_index] = '\0';
                    line_ready = 1;
                }
            } else {
                if (rx_index < UART_RX_BUF_SIZE - 1) {
                    rx_buffer[rx_index++] = rx_data;
                } else {
                    // Línea demasiado larga: descartar y reiniciar índice
                    rx_index = 0;
                }
            }
        }
        HAL_UART_Receive_IT(&huart2, &rx_data, 1);
    }
}

/* Cálculo de Porcentaje entero con redondeo correcto: PCT = round(100 * ADC / 4095) */
uint8_t Calculate_Percentage(uint16_t raw) {
    if (raw > 4095) raw = 4095;
    return (uint8_t)(((uint32_t)raw * 100 + 2047) / 4095);
}

void Send_Telemetry(void) {
    char msg[64];
    int len = snprintf(msg, sizeof(msg), "t=%lu;ADC=%u;PCT=%u;THR=%u;MODE=%s;ALARM=%u\r\n",
                        t_counter_ms, adc_raw, pct, thr,
                        (current_mode == MODE_RUN) ? "RUN" : "PAUSE", alarm_state);
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, len, 100);
}

void Send_Status(void) {
    char msg[64];
    int len = snprintf(msg, sizeof(msg), "t=%lu;ADC=%u;PCT=%u;THR=%u;MODE=%s;ALARM=%u\r\n",
                        ms_ticks, adc_raw, pct, thr,
                        (current_mode == MODE_RUN) ? "RUN" : "PAUSE", alarm_state);
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, len, 100);
}

void Process_Command(char* cmd) {
    if (strlen(cmd) == 0) return;

    if (strcmp(cmd, "STATUS") == 0) {
        Send_Status();
    } else if (strncmp(cmd, "THR ", 4) == 0) {
        int new_thr = atoi(cmd + 4);
        if (new_thr >= 10 && new_thr <= 95) {
            thr = (uint8_t)new_thr;
            if (current_mode == MODE_RUN && valid_sample_received) {
                alarm_state = (pct >= thr) ? 1 : 0;
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, alarm_state ? GPIO_PIN_SET : GPIO_PIN_RESET);
            }
            char resp[32];
            int len = snprintf(resp, sizeof(resp), "OK THR=%d\r\n", thr);
            HAL_UART_Transmit(&huart2, (uint8_t*)resp, len, 100);
        } else {
            HAL_UART_Transmit(&huart2, (uint8_t*)"ERR\r\n", 5, 100);
        }
    } else if (strcmp(cmd, "START") == 0) {
        if (current_mode != MODE_RUN) {
            current_mode = MODE_RUN;
            if (valid_sample_received) {
                alarm_state = (pct >= thr) ? 1 : 0;
            }
        }
        HAL_UART_Transmit(&huart2, (uint8_t*)"OK RUN\r\n", 8, 100);
    } else if (strcmp(cmd, "STOP") == 0) {
        current_mode = MODE_PAUSE;
        alarm_state = 0;
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
        HAL_UART_Transmit(&huart2, (uint8_t*)"OK PAUSE\r\n", 10, 100);
    } else {
        HAL_UART_Transmit(&huart2, (uint8_t*)"ERR\r\n", 5, 100);
    }
}
